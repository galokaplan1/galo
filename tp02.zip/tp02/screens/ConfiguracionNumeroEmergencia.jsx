import React, { useState, useEffect } from "react";
import { Button, StyleSheet, Text, TextInput, View, Keyboard } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { vibrar } from "../vibrar";

export default function ConfiguracionNumeroEmergencia() {
const [numero, setNumero] = useState();
const [error, setError] = useState(false);
const [Validado, setValidado] = useState(false);




useEffect(() => {
  const getValidado = async () => {

const oka = (await AsyncStorage.getItem("@numero"))
    oka = setValidado (await AsyncStorage.getItem("@numero"));
  }
  getValidado();
}, []);

const saveNumero = async () => {
  if (numero.length > 9) {
      setError(true);
      console.log(numero)
      Keyboard.dismiss();
      setValidado(await AsyncStorage.getItem("@numero"));
      
  } else {
      setError(false);
      alert('pon al menos 10 digitos')
        vibrar()
       saveNumero();
        await AsyncStorage.setItem('@numero', numero);
      
  }
}





 

return (
  <View style={styles.container}>
    {numero ? (
      <Text style={styles.heading}>Numero: {numero}</Text>
    ) : (
      <Text style={styles.heading}>Establecer Numero:</Text>
    )}
<Text>Numero Guardado: {Validado}</Text>
    <TextInput
      placeholder="Numero"
      style={styles.textInput}
      onChangeText={setNumero}
      value={numero}
    
    />
    <View style={styles.buttonContainer}>
    <Button title="Save" onPress={saveNumero} />
    
  </View>

  </View>
);
}

const styles = StyleSheet.create({
container: {
  flex: 1,
  flexDirection: "column",
  backgroundColor: "#fff",
  alignItems: "center",
  justifyContent: "center",
},
heading: {
  fontSize: 24,
},
textInput: {
  width: 300,
  marginVertical: 30,
  padding: 10,
  borderWidth: 1,
  borderColor: "#000",
  borderRadius: 50,
},
buttonContainer: {
  width: 240,
  display: "flex",
  flexDirection: "row",
  justifyContent: "space-evenly",
},
});