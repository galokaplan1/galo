import { StyleSheet, Text, View, Button , TouchableOpacity } from 'react-native';
import { useNavigation } from "@react-navigation/native";

export default function Home() {

  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <Text style = {styles.text}>Clima</Text>
      <Button onPress={() => navigation.navigate('Clima')} title="Clima" />

      <Text style = {styles.text}>Hora y clima:</Text>
      <Button onPress={() => navigation.navigate('Qr')} title="Qr"/>

      <Text style = {styles.text}>Contactos</Text>
      <Button onPress={() => navigation.navigate('Contactos')} title="contactos"/>

      <Text style = {styles.text}>Numero de Emergencia</Text>
      <Button onPress={() => navigation.navigate('ConfiguracionNumeroEmergencia')} title="Numero de Emergencia"/>


    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
  margin:5
  },
  button:{
    backgroundColor: `#008b8b`,
    borderWidth:2,
    borderColor: 'lightblue',
    borderRadius: 1,
    padding: 15,
    width: '50%',
    left: '25%',
    justifyContent:'center',
    marginTop:45

  }
});


            

    