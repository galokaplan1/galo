import { Vibration } from 'react-native';

export const vibrar = () => {
    Vibration.vibrate(1500);
}