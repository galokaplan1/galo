import { StyleSheet } from 'react-native'
import React from 'react'
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'
import Clima from '../screens/Clima'
import Home from '../screens/Home'
import Contactos from '../screens/Contactos'
import ConfiguracionNumeroEmergencia from '../screens/ConfiguracionNumeroEmergencia'
import QR from '../screens/Qr'

const Stack = createStackNavigator()

const MainStack = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name='Home' component={ Home }/>
          <Stack.Screen name='Qr' component={ QR }/>
          <Stack.Screen name='Contactos' component={ Contactos }/>
          <Stack.Screen name='Clima' component={ Clima }/>
          <Stack.Screen name='ConfiguracionNumeroEmergencia' component={ ConfiguracionNumeroEmergencia }/>
      </Stack.Navigator>
    </NavigationContainer>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%'
  },
});

export default MainStack